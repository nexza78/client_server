function addNote(note, context) {
    addAction({
        type: "add_note",
        note: note
    }, context);
}

function Topic(note, context){
    addAction({
        type: "new_topic",
        note: note
    }, context);
}

function newNote(note, context) {
    addAction({
        type: "new_note",
        note: note
    }, context);
}
function returnTopics(note, context) {
    addAction({
        type: "return_topic",
        note: note
    }, context);
}